/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

angular.module('ohanaApp').service('Api', function ($resource) {
    'use strict';

	//put url logic here to support localhost
	var l = window.location;
	var extension = (l.hostname === "localhost" || l.hostname.indexOf('txcdtl08tm638x') > -1) ?
		        "http://txcdt36an7383.itservices.sbc.com:1337"
            : l.protocol + '//' + l.hostname;

	return {
		// region controller -------------------------------------------------------------------
		region: $resource(extension + '/region', {}, {
			query: { method: 'GET' },
			save: { method: 'POST', isArray: false }
		}),
		region: $resource(extension + '/region/:region_id',
			{region_id: '@region_id'}, {
				update: { method: 'PUT' },
				remove: { method: 'DELETE', isArray: false }
            }),
		createChapter: $resource(extension + '/region/:region_id/create_chapter',
			{region_id: '@region_id'}, {
				save: { method: 'POST', isArray: false }
            }),
		regionAddChapter: $resource(extension + '/region/:region_id/add_chapter/:chapter_id',
			{region_id: '@region_id', chapter_id: '@chapter_id'}, {
				update: { method: 'PUT', isArray: false }
            }),
		regionDeleteChapter: $resource(extension + '/region/:region_id/delete_chapter/:chapter_id',
			{region_id: '@region_id', chapter_id: '@chapter_id'}, {
				remove: { method: 'POST', isArray: false }
            }),

		// chapter controller -------------------------------------------------------------------
		chapter: $resource(extension + '/chapter', {}, {
			query: { method: 'GET'}
        }),
		chapter: $resource(extension + '/chapter/:chapter_id',
			{chapter_id: '@chapter_id'}, {
				update: { method: 'PUT' }
            }),
		chapter: $resource(extension + '/chapter/:region_id',
			{region_id: '@region_id'}, {
				remove: { method: 'DELETE' }
            }),
		createEvent: $resource(extension + '/chapter/:chapter_id/create_event',
			{chapter_id: '@chapter_id'}, {
				save: { method: 'POST', isArray: false }
            }),
		chapterAddEvent: $resource(extension + '/chapter/:chapter_id/add_event/:event_id',
			{event_id: '@event_id', chapter_id: '@chapter_id'}, {
				update: { method: 'PUT', isArray: false }
            }),
		chapterRemoveEvent: $resource(extension + '/chapter/:chapter_id/delete_event/:event_id',
			{event_id: '@event_id', chapter_id: '@chapter_id'}, {
				remove: { method: 'POST', isArray: false }
            }),
        createItem: $resource(extension + '/chapter/:chapter_id/create_item',
			{chapter_id: '@chapter_id'}, {
				save: { method: 'POST', isArray: false }
            }),
		chapterAddItem: $resource(extension + '/chapter/:chapter_id/add_item/:item_id',
			{item_id: '@item_id', chapter_id: '@chapter_id'}, {
				update: { method: 'PUT', isArray: false }
            }),
		chapterRemoveItem: $resource(extension + '/chapter/:chapter_id/delete_item/:item_id',
			{item_id: '@item_id', chapter_id: '@chapter_id'}, {
				remove: { method: 'POST', isArray: false }
            }),
        
		// events controller -------------------------------------------------------------------
		events: $resource(extension + '/events', {}, {
			query: { method: 'GET'}
        }),
		events: $resource(extension + '/events/:event_id',
			{event_id: '@event_id'}, {
				update: { method: 'PUT' }
            }),
		addMemberToEvent: $resource(extension + '/events/:event_id/add_member/:member_id',
			{event_id: '@event_id', member_id: '@member_id'}, {
				save: { method: 'POST', isArray: false }
            }),
		dropMemberFromEvent: $resource(extension + '/events/:event_id/drop_member/:member_id',
			{event_id: '@event_id', member_id: '@member_id'}, {
				remove: { method: 'POST', isArray: false }
            }),
        reserveItemToEvent: $resource(extension + '/events/:event_id/reserve_item/:item_id',
			{item_id: '@item_id', member_id: '@member_id'}, {
				save: { method: 'POST', isArray: false }
            }),
		freeItemFromEvent: $resource(extension + '/events/:event_id/free_item/:item_id',
			{item_id: '@item_id', member_id: '@member_id'}, {
				remove: { method: 'POST', isArray: false }
            }),

		// items controller
        item: $resource(extension + '/item', {}, {
            query: { method: 'GET' }
        }),
		// more routes for create/delete reservations and update items
        
        // member controller -------------------------------------------------------------------
		// NOTE posting in a member includes the option to create a login
        member: $resource(extension + '/member', {}, {
			query: { method: 'GET' },
			save: { method: 'POST', isArray: false }
		}),
        member: $resource(extension + '/member/:member_id', {id: '@id'}, {
			update: { method: 'PUT' },
			remove: { method: 'DELETE', isArray: false }
		}),
        createLogin: $resource(extension + '/member/:member_id/create_login',
            {member_id: '@member_id'}, {
                save: { method: 'POST', isArray: false }
            }),
		retrieveLogin: $resource(extension + '/member/get_login/:member_id', {id: '@id'}, {
			query: { method: 'GET' }
		}),
		updateLogin: $resource(extension + '/member/login/update/:member_id', {id: '@id'}, {
			update: { method: 'PUT' }
		}),

		// session controller
        session: $resource(extension + '/session/login', {}, {
			query: { method: 'GET' },
			save: { method: 'POST', isArray: false }
		})
    };

});
