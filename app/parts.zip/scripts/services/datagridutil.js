/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc service
 * @name ohanaApp.dataGridUtil
 * @description
 * # dataGridUtil
 * Service in the ohanaApp.
 */
angular.module('ohanaApp')
    .service('dataGridUtil', function () {
        'use strict';
        var dataGridUtil = this;

        dataGridUtil.buildTableData = function (results) {
            // console.log(results);
            var resultsLen = results.length;
            // var headersLen = 10;
            var gridData = [];

            // build data table from http response
            for (var i = 0; i < resultsLen; i++) {
                var arr = {};
                arr.DT_RowId = results[i].id;
                arr.first_name = results[i].first_name;
                arr.last_name = results[i].last_name;
                var dobparse = new Date(results[i].DOB);
                var endob = dobparse.toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit'
                });
                arr.dob = endob;
                arr.email = results[i].email;
                arr.mobile_number = results[i].mobile_number;
                arr.role = results[i].role;
                arr.region = results[i].region;
                arr.chapter = results[i].chapter;
                if (results[i].military_affiliation) {
                    arr.military_affiliation = results[i].military_affiliation;
                } else {
                    arr.military_affiliation = "";
                }
                if (results[i].notes) {
                    arr.notes = results[i].notes;
                } else {
                    arr.notes = "";
                }

                // NOTE FOR IF THE DATA IS STORED IN ARRAYS NOT OBJECTS LIKE ABOVE
                // var arr = [];
                // arr.push("");
                // arr.push(results[i].id);
                // arr.push(results[i].first_name);
                // arr.push(results[i].last_name);
                // var dob = new Date(results[i].DOB);
                // var endob = dob.toLocaleDateString('en-US', {year:'numeric', month:'2-digit', day:'2-digit'});
                // arr.push(endob);
                // arr.push(results[i].email);
                // arr.push(results[i].mobile_number);
                // arr.push(results[i].role);
                // arr.push(results[i].region);
                // arr.push(results[i].chapter);
                // if (results[i].military_affiliation) {
                //   arr.push(results[i].military_affiliation);
                // } else {
                //   arr.push("");
                // }
                // if (results[i].notes) {
                //   arr.push(results[i].notes);
                // } else {
                //   arr.push("");
                // }

                gridData.push(arr);
            }
            // console.log(gridData);
            return gridData;
        };
    });
