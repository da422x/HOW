/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc directive
 * @name ohanaApp.directive:managernavigation
 * @description
 * # managernavigation
 */
angular.module('ohanaApp')
    .directive('managerNavigation', function () {
        'use strict';
        return {
            templateUrl: 'views/managernav.html',
            restrict: 'E',
            controller: function ($scope) {

                // $scope.role = 'volunteer';
                // $scope.userRole = 'eventManager';
                // $scope.navSelection = "";
                // $scope.role = 'chapterManager';
                // $scope.role = 'regionManager';

                // function updateNavSelection() {
                //     if ($scope.userRole == 'volunteer') {
                //         $scope.navSelection = 'volunteerNavs';
                //     } else if ($scope.userRole == 'eventManager') {
                //         $scope.navSelection = 'eventMngrNavs';
                //     } else if ($scope.userRole == 'chapterManager') {
                //         $scope.navSelection = 'chapterMngrNavs';
                //     } else if ($scope.userRole == 'regionManager') {
                //         $scope.navSelection = 'regionMngrNavs';
                //     }
                // };

                $scope.volunteerNavs = [{
                    state: "dash",
                    text: "Dashboard"
                }, {
                    state: "events",
                    text: "My Opportunities"
                }, {
                    state: "hours",
                    text: "My Hours"
                }, {
                    state: "training",
                    text: "My Training"
                }];

                $scope.eventMngrNavs = [{
                    state: "dash",
                    text: "Dashboard"
                }, {
                    state: "events",
                    text: "Events"
                }, {
                    state: "broadcasts",
                    text: "Broadcasts"
                }, {
                    state: "inventory",
                    text: "Inventory"
                }, {
                    state: "training",
                    text: "My Training"
                }];

                $scope.chapterMngrNavs = [{
                    state: "dash",
                    text: "Dashboard"
                }, {
                    state: "events",
                    text: "Events"
                }, {
                    state: "broadcasts",
                    text: "Broadcasts"
                }, {
                    state: "inventory",
                    text: "Inventory"
                }, {
                    state: "training",
                    text: "My Training"
                }, {
                    state: "directory",
                    text: "Member Directory"
                }, {
                    state: "chAdmin",
                    text: "Chapter Administration"
                }];

                $scope.regionMngrNavs = [{
                    state: "dash",
                    text: "Dashboard"
                }, {
                    state: "events",
                    text: "Events"
                }, {
                    state: "broadcasts",
                    text: "Broadcasts"
                }, {
                    state: "inventory",
                    text: "Inventory"
                }, {
                    state: "training",
                    text: "My Training"
                }, {
                    state: "directory",
                    text: "Member Directory"
                }, {
                    state: "regAdmin",
                    text: "Region Administration"
                }];

                $scope.adminNavs = [{
                    state: "dash",
                    text: "Dashboard"
                }, {
                    state: "events",
                    text: "Events"
                }, {
                    state: "broadcasts",
                    text: "Broadcasts"
                }, {
                    state: "inventory",
                    text: "Inventory"
                }, {
                    state: "training",
                    text: "My Training"
                }, {
                    state: "directory",
                    text: "Member Directory"
                }, {
                    state: "donors",
                    text: "Donor Management"
                }, {
                    state: "superAdmin",
                    text: "Administration"
                }];
            }
        };
    });
