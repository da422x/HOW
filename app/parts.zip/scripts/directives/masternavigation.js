/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc directive
 * @name ohanaApp.directive:masternavigation
 * @description
 * # masternavigation
 */
angular.module('ohanaApp')
    .directive('masterNavigation', function () {
        'use strict';
        return {
            templateUrl: 'views/masternav.html',
            restrict: 'E',

            controller: function ($scope) {
                $scope.sessionState = false;
                $scope.$on('changeSessionState', function (event, arg) {
                    $scope.sessionState = arg;
                });

                $scope.leftnav = [{
                    state: "about",
                    text: "WHO WE ARE"
                }, {
                    state: "getinvolved",
                    text: "GET INVOLVED"
                }, {
                    state: "eventsTicker",
                    text: "EVENTS"
                }];

                $scope.rightnav = [{
                    state: "login",
                    text: "LOGIN"
                }];

                $scope.rightnavloggedin = [{
                    state: "manage",
                    text: "MANAGE"
                }];
            }
        };
    });
