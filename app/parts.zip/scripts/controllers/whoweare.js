/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc function
 * @name ohanaApp.controller:WhoweareCtrl
 * @description
 * # WhoweareCtrl
 * Controller of the ohanaApp
 */
angular.module('ohanaApp')
    .controller('WhoweareCtrl', function () {
        'use strict';
        // empty controller
    });
