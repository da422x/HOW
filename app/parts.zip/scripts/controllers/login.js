/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc function
 * @name ohanaApp.controller:LoginCtrl
 * @description
 * # LoginCtrl
 * Controller of login page
 */
angular.module('ohanaApp')
    .controller('LoginCtrl', function (Api, $state, $scope, $rootScope) {
        'use strict';

        $scope.logObj = {};
        $scope.checkLogin = function () {
            // log.loginRequest = Api.login.save({
            //   "username":this.login.username,
            //   "password":this.login.password
            // });.

            $rootScope.$broadcast('changeSessionState', 'true');
            $state.go('dash');

            // $scope.loginRequest.$promise.then( function(data) {
            //   $state.go('manage');
            //   // console.log(data);
            //   // console.log("OH YEAH.");
            // }, function(data) {
            //   $scope.loginForm.$invalid = true;
            //   // console.log(log);
            // }
            // );
            // log.login = {};
        };

        // return true;
    });
