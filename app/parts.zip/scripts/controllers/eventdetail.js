/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc function
 * @name ohanaApp.controller:DetailsCtrl
 * @description
 * # DetailsCtrl
 * Controller of the ohanaApp
 */
angular.module('ohanaApp')
    .controller('DetailsCtrl', function ($http, $scope, $location) {
        'use strict';

        var self = this;
        $scope.goBackToEvents = function () {
            $location.url('/manage/events');
        };

        $http.get('/testData/events.json').then(
            function (response) {
                self.data = response.data[$location.search().id];
                $scope.title = self.data.title;
                $scope.location = self.data.where.locationName;
            },
            function (response) {
                console.log(response.status);
            }
        );
    });
