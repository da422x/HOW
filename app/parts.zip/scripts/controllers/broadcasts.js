/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc function
 * @name ohanaApp.controller:BroadcastsCtrl
 * @description
 * # BroadcastsCtrl
 * Controller of the management console - broadcasts
 */
angular.module('ohanaApp')
    .controller('BroadcastsCtrl', function ($scope) {
        'use strict';

        $scope.options = {
            height: 400
            // maxHeight: 400,
            // minHeight: 100,
            // focus: true
        };

    });
