/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc function
 * @name ohanaApp.controller:EventdetailparticipantsCtrl
 * @description
 * # EventdetailparticipantsCtrl
 * Controller of the ohanaApp
 */

angular.module('ohanaApp')
    .controller('EventdetailparticipantsCtrl', function ($http, $scope) {
        'use strict';

        $http.get('/testData/event.participants.json').then(
            function (result) {
                console.log(result.data.data);
                console.log(result.status);
                $scope.participantList = result.data.data;
            },
            function (result) {
                console.log(result.data.data);
                console.log(result.status);
            }
        );
    });
