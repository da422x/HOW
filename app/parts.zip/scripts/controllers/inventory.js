/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc function
 * @name ohanaApp.controller:InventoryCtrl
 * @description
 * # InventoryCtrl
 * Controller of the ohanaApp
 */
angular.module('ohanaApp')
    .controller('InventoryCtrl', function ($scope) {
        'use strict';

        angular.element(document).ready(function () {
            var i;
            
            //toggle `popup` / `inline` mode
            $.fn.editable.defaults.mode = 'popup';
            $.fn.editable.defaults.ajaxOptions = {
                type: "PUT"
            };
            
            $scope.inventoryTable = $('#inventoryTable').DataTable({
                ajax: 'testData/inventory.json',
                columns: [
                    {
                        title: "ID"
                    },
                    {
                        title: "Item Name"
                    },
                    {
                        title: "Category"
                    },
                    {
                        title: "Condition"
                    },
                    {
                        title: "Purchase Date"
                    },
                    {
                        title: "Reserved?"
                    },
                    {
                        title: "Location"
                    },
                    {
                        title: "Notes"
                    }
                ],
                rowCallback: function (row, data, index) {
                    // console.log('row:', row, 'data:', data, 'index:', index);
                    $(row).children().eq(1).addClass('tdText');
                    $(row).children().eq(2).addClass('tdText');
                    $(row).children().eq(3).addClass('tdText');
                    $(row).children().eq(4).addClass('tdText');
                    $(row).children().eq(5).addClass('tdCombodate');
                    $(row).children().eq(7).addClass('tdText');
                    $(row).children().eq(8).addClass('tdTextarea');
                    for (i = 1; i < 6; i++) {
                        $(row).children().eq(i).wrapInner('<a class="editable editable-click"></a>');
                    }
                    $(row).children().eq(7).wrapInner('<a class="editable editable-click"></a>');
                    $(row).children().eq(8).wrapInner('<a class="editable editable-click"></a>');

                    return row;
                },
                drawCallback: function () {
                    $('#inventoryTable .tdText a').editable({
                        type: "text",
                        placement: "bottom",
                        emptytext: "null"
                    });
                    $('#inventoryTable .tdTextarea a').editable({
                        type: "textarea",
                        placement: "bottom",
                        emptytext: "null"
                    });
                    $('#inventoryTable .tdCombodate a').editable({
                        type: "combodate",
                        placement: "bottom",
                        emptytext: "null",
                        format: 'yyyy-mm-dd',
                        viewformat: 'mm/dd/yyyy',
                        datepicker: {
                            weekstart: 1
                        }
                    });
                }
            }).columns.adjust().draw();

            //if exists, destroy instance of table
            if ($.fn.DataTable.isDataTable($('inventoryTable'))) {
                $scope.membersTable.destroy();
            }

        });
    });
