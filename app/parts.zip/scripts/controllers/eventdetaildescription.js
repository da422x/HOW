/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc function
 * @name ohanaApp.controller:EventdetaildescriptionCtrl
 * @description
 * # EventdetaildescriptionCtrl
 * Controller of the ohanaApp
 */
angular.module('ohanaApp')
    .controller('EventdetaildescriptionCtrl', function ($scope) {
        'use strict';

        $scope.endTime = "";
        $scope.startTime = "";

        $scope.dateOptions = {
            formatYear: 'yy',
            maxDate: new Date(2020, 5, 22),
            minDate: new Date(),
            startingDay: 1
        };

        $scope.today = function () {
            //TODO: Check if the event date is actually set
            var dateToday = new Date();
            $scope.st = dateToday;
            $scope.et = dateToday;
        };

        $scope.today();

        // TODO: Combine these functions into one that handles the option
        // based on which picker was clicked
        $scope.openStartDate = function () {
            $scope.startDate.opened = true;
        };

        $scope.openEndDate = function () {
            $scope.endDate.opened = true;
        };

        // TODO: Make one object that stores the state of both pickers
        $scope.startDate = {
            opened: false
        };

        $scope.endDate = {
            opened: false
        };

        // TODO: Add a check to see if the end time is later than the start time
    });
