/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc function
 * @name ohanaApp.controller:EventdetailnotificationCtrl
 * @description
 * # EventdetailnotificationCtrl
 * Controller of the ohanaApp
 */
angular.module('ohanaApp')
    .controller('EventdetailnotificationCtrl', function ($scope) {
        'use strict';
        $scope.distros = ['b@example.com', 'c@example.com'];
        $scope.recipient = [];
        $scope.ccVisible = false;
        $scope.bccVisible = false;

        $scope.toggleCC = function () {
            this.ccVisible = !this.ccVisible;
        }

        $scope.toggleBCC = function () {
            this.bccVisible = !this.bccVisible;
        }

        $scope.options = {
            height: 600,
            // maxHeight: 400,
            // minHeight: 100,
            // focus: true
        };
    });
