/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc function
 * @name ohanaApp.controller:EventdetailequipmentCtrl
 * @description
 * # EventdetailequipmentCtrl
 * Controller of the ohanaApp
 */
angular.module('ohanaApp')
    .controller('EventdetailequipmentCtrl', function () {
        'use strict';
        // empty controller
    });
