/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc function
 * @name ohanaApp.controller:DashManageCtrl
 * @description
 * # DashManageCtrl
 * Controller of management console - dashboard
 */
angular.module('ohanaApp')
    .controller('DashCtrl', function () {
        'use strict';
        // empty controller
    });
