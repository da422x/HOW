/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc function
 * @name ohanaApp.controller:NewuserCtrl
 * @description
 * # NewuserCtrl
 * Controller of create user page
 */
angular.module('ohanaApp')
    .controller('NewuserCtrl', function () {
        'use strict';

        this.login = {};

        // this.checkLogin = function(thing) {
        //   this.loginRequest = Api.login.({
        //     "username":this.login.username,
        //     "password":this.login.password
        //   });
        //
        //   this.loginRequest.$promise.then(function(data){
        //     console.log(data);
        //     console.log("OH YEAH.");
        //   });
        //   this.login = {};
        // }
    });
