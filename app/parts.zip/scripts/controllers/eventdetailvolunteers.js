/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc function
 * @name ohanaApp.controller:EventdetailvolunteersCtrl
 * @description
 * # EventdetailvolunteersCtrl
 * Controller of the ohanaApp
 */

angular.module('ohanaApp')
    .controller('EventdetailvolunteersCtrl', function ($http, $scope) {
        'use strict';

        $http.get('/testData/event.volunteers.json').then(
            function (result) {
                console.log(result.data.data);
                console.log(result.status);
                $scope.volunteerList = result.data.data;
            },
            function (result) {
                console.log(result.data.data);
                console.log(result.status);
            }
        );
    });
