/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc function
 * @name ohanaApp.controller:EventsCtrl
 * @description
 * # EventsCtrl
 * Controller of the ohanaApp
 */
angular.module('ohanaApp')
    .controller('EventsCtrl', function ($http, $scope, $location) {
        'use strict';

        $http.get('/testData/events.json').then(
            function (result) {
                console.log(result.data);
                console.log(result.status);
                $scope.eventList = result.data;

                $scope.manageEvent = function (eventID) {
                    $location.path('/manage/events/detail/description').search({
                        id: eventID
                    });
                };
            },
            function (result) {
                console.log(result.data);
                console.log(result.status);
            }
        );
    });
