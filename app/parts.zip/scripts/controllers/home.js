/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc function
 * @name ohanaApp.controller:HomeCtrl
 * @description
 * # HomeCtrl
 * Controller of homepage
 */
angular.module('ohanaApp')
    .controller('HomeCtrl', function ($scope) {
        'use strict';

        $scope.vidtoggle = false;

        $scope.videoToggle = function () {
            if ($scope.vidtoggle) {
                $scope.vidtoggle = false;
                $('#videoplayer').each(function () {
                    this.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
                });
            } else if (!$scope.vidtoggle) {
                $scope.vidtoggle = true;
            } else {
                $scope.vidtoggle = false;
                $('#videoplayer').each(function () {
                    this.contentWindow.postMessage('{"event":"command","func":"pauseVideo","args":""}', '*');
                });
            }
        };

    });
