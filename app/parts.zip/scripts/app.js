/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc overview
 * @name ohanaApp
 * @description
 * # ohanaApp
 *
 * Main module of the application.
 */
angular
    .module('ohanaApp', [
        'ngAnimate',
        'ui.bootstrap',
        'ui.router',
        'ngCookies',
        'ngMessages',
        'ngResource',
        'ngRoute',
        'ngSanitize',
        'ngTouch',
        'summernote',
        'ui.timepicker'
    ])
    .config(function ($stateProvider) {
        'use strict';
        $stateProvider
            .state('home', {
                url: "/",
                templateUrl: 'views/home.html',
                controller: 'HomeCtrl as home'
            })
            .state('whoweare', {
                url: '/whoweare',
                templateUrl: 'views/whoweare.html',
                controller: 'WhoweareCtrl as whoweare'
            })
            .state('getinvolved', {
                url: '/getinvolved',
                templateUrl: 'views/getinvolved.html',
                controller: 'GetinvolvedCtrl as getinvolved'
            })
            .state('login', {
                url: "/login",
                templateUrl: 'views/login.html',
                controller: 'LoginCtrl as login'
            })
            .state('newUser', {
                url: "/newUser",
                templateUrl: 'views/newuser.html',
                controller: 'NewuserCtrl as newUser'
            })
            .state('dash', {
                url: "/manage/dash",
                templateUrl: 'views/manage/dash.html',
                controller: 'DashCtrl as dash'
            })
            .state('events', {
                url: "/manage/events",
                templateUrl: 'views/manage/events.html',
                controller: 'EventsCtrl as events'
            })
            .state('eventDetail', {
                url: "/manage/events/detail",
                templateUrl: 'views/manage/event.details.html',
                controller: 'DetailsCtrl as eventDetail'
            })
            .state('eventDetail.description', {
                url: "/description",
                templateUrl: 'views/manage/event.details.description.html',
                controller: 'EventdetaildescriptionCtrl as eventDescription'
            })
            .state('eventDetail.volunteers', {
                url: "/volunteers",
                templateUrl: 'views/manage/event.details.volunteers.html',
                controller: 'EventdetailvolunteersCtrl as eventVolunteers'
            })
            .state('eventDetail.participants', {
                url: "/volunteers",
                templateUrl: 'views/manage/event.details.participants.html',
                controller: 'EventdetailparticipantsCtrl as eventParticipants'
            })
            .state('eventDetail.equipment', {
                url: "/equipment",
                templateUrl: 'views/manage/event.details.equipment.html',
                controller: 'EventdetailequipmentCtrl as eventEquipment'
            })
            .state('eventDetail.notifications', {
                url: "/volunteers",
                templateUrl: 'views/manage/event.details.notifications.html',
                controller: 'EventdetailnotificationCtrl as eventNotifications'
            })
            .state('broadcasts', {
                url: "/manage/broadcasts",
                templateUrl: 'views/manage/broadcasts.html',
                controller: 'BroadcastsCtrl as broadcasts'
            })
            .state('inventory', {
                url: '/manage/inventory',
                templateUrl: 'views/manage/inventory.html',
                controller: 'InventoryCtrl as inventory'
            })
            .state('training', {
                url: '/manage/training',
                templateUrl: 'views/manage/training.html',
                controller: 'TrainingCtrl as training'
            })
            .state('hours', {
                url: '/manage/hours',
                templateUrl: 'views/manage/hours.html',
                controller: 'HoursCtrl'
            })
            .state('directory', {
                url: '/manage/directory',
                templateUrl: 'views/manage/directory.html',
                controller: 'DirectoryCtrl'
            })
            .state('donors', {
                url: '/manage/donors',
                templateUrl: 'views/manage/donors.html',
                controller: 'DonorsCtrl'
            });
    });
