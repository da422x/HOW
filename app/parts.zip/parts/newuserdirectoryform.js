/*jslint browser: true, devel: true, bitwise: true, eqeq: true, plusplus: true, vars: true, indent: 4*/
/*global angular, $, console, swal*/

/**
 * @ngdoc function
 * @name ohanaApp.controller:NewuserdirectoryformCtrl
 * @description
 * # NewuserdirectoryformCtrl
 * Controller of the ohanaApp
 */
angular.module('ohanaApp')
    .controller('NewUserDirectoryFormCtrl', function ($scope, $uibModalInstance, Api) {
        'use strict';

        // calendar options
        $scope.popup = {
            opened: false
        };
        $scope.format = 'MM/dd/yyyy';
        $scope.dateOptions = {
            maxDate: new Date(),
            startingDay: 0,
            showWeeks: false
        };
        $scope.open = function () {
            $scope.popup.opened = true;
        };

        // regions dropdown data
        $scope.regions = [
            {
                value: "northeast",
                displayName: "Northeast (NJ, NY, PA, ME, MA)"
            },
            {
                value: "midatlantic",
                displayName: "Mid-Atlantic (MD, VA, NC)"
            },
            {
                value: "midwest",
                displayName: "Midwest (IN, NE, AR, IA, KS, IL, MN, WI, MO, TN)"
            },
            {
                value: "southeast",
                displayName: "Southeast (FL, GA, SC, AL)"
            },
            {
                value: "southwest",
                displayName: "Southwest (OK, TX, LA)"
            },
            {
                value: "west",
                displayName: "West (AZ, CA, OR, WA, UT, HI)"
            }
        ];

        // roles radio data
        $scope.roles = [
            {
                value: "volunteer",
                displayName: "Volunteer"
            },
            {
                value: "event_manager",
                displayName: "Event Manager"
            },
            {
                value: "chapter_manager",
                displayName: "Chapter Manager"
            },
            {
                value: "region_manager",
                displayName: "Region Manager"
            },
            {
                value: "admin",
                displayName: "Administrator"
            }
        ];

        $scope.regionUpdate = function () {
            // If region is empty
            // console.log('hello');
            // if(this == null){
            //   console.log('this is null');
            // } else if (this == "") {
            //   console.log('this is empty');
            // }
            console.log($scope.newUserDirectory.region.value);


        };

        // empty submit object
        $scope.newUserDirectory = {};

        $scope.postUser = function () {
            // submit form
            $scope.newUserDirectory.role = $("input[name='role']:checked").val();
            $scope.newUserDirectory.chapter = $("#chapter :selected").val();
            $scope.newUserDirectory.region = $scope.newUserDirectory.region.value;
            // check required fields if blank
            if ($scope.newUserDirectory.first_name == null ||
                    $scope.newUserDirectory.last_name == null ||
                    $scope.newUserDirectory.email == null ||
                    $scope.newUserDirectory.mobile_number == null ||
                    $scope.newUserDirectory.role == null ||
                    $scope.newUserDirectory.region == null ||
                    $scope.newUserDirectory.chapter == null) {
                console.log($scope.newUserDirectory);
                console.log('ERROR');
                swal({
                    text: "Form incomplete!",
                    type: 'warning',
                    timer: 2500
                });
            } else {
                console.log($scope.newUserDirectory);
                console.log('SUCCESS');
                Api.member.save($scope.newUserDirectory).$promise.then(
                    function (val) {
                        swal({
                            text: "User added!",
                            type: 'success',
                            timer: 2500
                        });
                        $uibModalInstance.close();
                    },
                    function (error) {
                        swal({
                            text: "Error submitting data. Please try again",
                            type: 'error',
                            timer: 2500
                        });
                    }
                );

            }

        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

    });
